import 'package:flutter/material.dart';
import 'package:hello_world/src/app.dart';

void main() {
  runApp(const Myapp());
}